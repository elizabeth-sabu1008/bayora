# Bayora Cryptographic Evidence Pack
**Round ID:** `rnd_cc963e45ed82`
**Name:** Acceptance Benchmark Round
**State:** `COMPLETED`
**Verification Status:** `COMPLETED`
**Generated At:** 2026-10-26T11:07:00.470316+00:00

---

## 1. Cryptographic Hashes & Commitments
- **Red Commitment Hash:** `4100309bdcb2665c2bfb0a8605b3694eee0e0a32de5768d8430e2470cae476da`
- **Blue Commitment Hash:** `48b97a8a59b3b0e138ea7cacd6f8888e28cae549428b25b91ac5d9680c9b61bf`
- **Defense Artifact SHA-256:** `None`
- **Pre-Run Model Weights SHA-256:** `None`
- **Post-Run Model Weights SHA-256:** `None`
- **Weights Integrity:** FAILED

---

## 2. Audit Trail
- **Total Chained Events:** 10
- **Chain Head SHA-256:** `f41d411dde13aa92b24db6a9f0b0f522b2edbd24af4976efbda10d42760d68c6`
- **Auditor Signature:** Valid Ed25519 Signed Checkpoint

---

## 3. How to Independently Verify
Run the Bayora CLI or Python SDK verification tool:
```bash
bayora verify evidence_rnd_cc963e45ed82.zip
```
