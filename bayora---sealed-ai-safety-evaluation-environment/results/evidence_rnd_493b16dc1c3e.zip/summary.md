# Bayora Cryptographic Evidence Pack
**Round ID:** `rnd_493b16dc1c3e`
**Name:** Acceptance Benchmark Round
**State:** `COMPLETED`
**Verification Status:** `COMPLETED`
**Generated At:** 2026-10-26T11:04:06.380205+00:00

---

## 1. Cryptographic Hashes & Commitments
- **Red Commitment Hash:** `e8f6b44bf6e4fd6dd5c5e948a2ce02d5a2699fe4645ca811856f24141b4bcda2`
- **Blue Commitment Hash:** `52e838d0c40744f9b68b2a3278b76b89dd11cdbcdb7569edb33cf261fa9f164b`
- **Defense Artifact SHA-256:** `None`
- **Pre-Run Model Weights SHA-256:** `None`
- **Post-Run Model Weights SHA-256:** `None`
- **Weights Integrity:** FAILED

---

## 2. Audit Trail
- **Total Chained Events:** 10
- **Chain Head SHA-256:** `2438e49959a62a4527f56858520b503da8d6afc801bf6a8ccd54c45f2fbee79e`
- **Auditor Signature:** Valid Ed25519 Signed Checkpoint

---

## 3. How to Independently Verify
Run the Bayora CLI or Python SDK verification tool:
```bash
bayora verify evidence_rnd_493b16dc1c3e.zip
```
